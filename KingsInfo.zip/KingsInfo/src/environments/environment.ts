// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false ,
  firebase: {
    apiKey: "AIzaSyCViH0niaipsLVW86-oAJ395P5lvqwxubk",
    authDomain: "kingsinfo-be2e6.firebaseapp.com",
    projectId: "kingsinfo-be2e6",
    storageBucket: "kingsinfo-be2e6.appspot.com",
    messagingSenderId: "850540438242",
    appId: "1:850540438242:web:d2310efe38385813f374bb",
    measurementId: "G-47MZ7RV3W5"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
