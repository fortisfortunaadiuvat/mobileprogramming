import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.page.html',
  styleUrls: ['./navigation.page.scss'],
})
export class NavigationPage implements OnInit {

  constructor(private navCntl: NavController) { }

  ngOnInit() {
  }

  async goToClassicalEra(){
    this.navCntl.navigateForward('classical-era-hero');
  }

  async goToMiddleAges(){
    this.navCntl.navigateForward('middle-ages-hero');
  }

  async goToEarlyModernEra(){
    this.navCntl.navigateForward('early-modern-ages-hero');
  }

  async goToModernEra(){
    this.navCntl.navigateForward('modern-ages-hero');
  }

  async navigate(){
    this.navCntl.navigateBack('login');
  }

}
