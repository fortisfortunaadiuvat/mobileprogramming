import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFireAuth } from '@angular/fire/auth';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  user = {
    email : '',
    password: ''
  }

  constructor(private router: Router,
              public ngFireAuth: AngularFireAuth) { }

  ngOnInit() {
  }

  async login(){
    //code for log in user goes.
    const user = await this.ngFireAuth.signInWithEmailAndPassword(this.user.email,this.user.password);
    console.log(user);

    if(user.user.email){
      this.router.navigate(['/navigation']);
    }else{
      alert('login failed!');
    }
  }

  async register(){
    //code for log in user goes
    const user = await this.ngFireAuth.createUserWithEmailAndPassword(this.user.email,this.user.password);
    
    console.log(user);

    if(user.user.email){
      alert('registeration successfull!');
    }else{
      alert('registeration failed!');
    }
  }
  async guest(){
    this.router.navigate(['/navigation']);
  } 
}