export interface King {
    id: number;
    name: string;
    information: string;
}
