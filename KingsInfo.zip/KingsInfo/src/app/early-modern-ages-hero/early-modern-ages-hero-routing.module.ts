import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EarlyModernAgesHeroPage } from './early-modern-ages-hero.page';

const routes: Routes = [
  {
    path: '',
    component: EarlyModernAgesHeroPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EarlyModernAgesHeroPageRoutingModule {}
