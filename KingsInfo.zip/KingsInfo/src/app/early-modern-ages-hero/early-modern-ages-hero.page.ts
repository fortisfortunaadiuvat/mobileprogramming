import { Component, OnInit } from '@angular/core';
import { King } from '../king';
import { KingService } from "../king.service";
import { MessagesService } from "../messages.service";
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-early-modern-ages-hero',
  templateUrl: './early-modern-ages-hero.page.html',
  styleUrls: ['./early-modern-ages-hero.page.scss'],
})
export class EarlyModernAgesHeroPage implements OnInit {
  kings:King[];

  selectedKing: King;

  constructor(private kingService: KingService,
              private messageService:MessagesService,
              private navController: NavController) { }

  onSelect(king: King):void{
    this.selectedKing = king;
    this.messageService.add('King s page: Kings id:' + this.selectedKing.id);
  }

  getKings():void{
    //if data change somewhere, catch it
    this.kingService.getKings().subscribe(kings => this.kings=kings);
  }

  ngOnInit() {
    this.getKings();
  }

  navigate(){
    this.navController.navigateBack('navigation');
  }
}
