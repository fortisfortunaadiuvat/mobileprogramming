import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { EarlyModernAgesHeroPage } from './early-modern-ages-hero.page';

describe('EarlyModernAgesHeroPage', () => {
  let component: EarlyModernAgesHeroPage;
  let fixture: ComponentFixture<EarlyModernAgesHeroPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EarlyModernAgesHeroPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(EarlyModernAgesHeroPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
