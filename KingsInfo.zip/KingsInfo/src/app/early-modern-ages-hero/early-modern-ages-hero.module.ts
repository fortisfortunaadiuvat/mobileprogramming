import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EarlyModernAgesHeroPageRoutingModule } from './early-modern-ages-hero-routing.module';

import { EarlyModernAgesHeroPage } from './early-modern-ages-hero.page';

import { MessagesComponent } from "../messages/messages.component";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EarlyModernAgesHeroPageRoutingModule,
  ],
  declarations: [EarlyModernAgesHeroPage,MessagesComponent]
})
export class EarlyModernAgesHeroPageModule {}
