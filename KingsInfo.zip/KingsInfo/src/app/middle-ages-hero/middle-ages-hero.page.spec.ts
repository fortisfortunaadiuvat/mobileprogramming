import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MiddleAgesHeroPage } from './middle-ages-hero.page';

describe('MiddleAgesHeroPage', () => {
  let component: MiddleAgesHeroPage;
  let fixture: ComponentFixture<MiddleAgesHeroPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiddleAgesHeroPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MiddleAgesHeroPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
