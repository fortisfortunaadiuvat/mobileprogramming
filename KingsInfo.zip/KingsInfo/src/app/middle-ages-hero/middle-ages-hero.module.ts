import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MiddleAgesHeroPageRoutingModule } from './middle-ages-hero-routing.module';

import { MiddleAgesHeroPage } from './middle-ages-hero.page';

import { MessagesComponent } from "../messages/messages.component";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MiddleAgesHeroPageRoutingModule
  ],
  declarations: [MiddleAgesHeroPage,MessagesComponent]
})
export class MiddleAgesHeroPageModule {}
