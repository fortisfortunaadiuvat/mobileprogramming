import { Injectable } from '@angular/core';
import { King } from './king';
import { KINGS } from "./mock-king";
import { Observable, of } from "rxjs";
import { MessagesService } from "./messages.service";

@Injectable({
  providedIn: 'root'
})
export class KingService {

  constructor(private messageService: MessagesService) { }

  getKings(): Observable<King[]>{
    this.messageService.add('KingService: fetched king!');

    //resource(ex:database)
    return of(KINGS);
  }
}
