import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ModernAgesHeroPage } from './modern-ages-hero.page';

describe('ModernAgesHeroPage', () => {
  let component: ModernAgesHeroPage;
  let fixture: ComponentFixture<ModernAgesHeroPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModernAgesHeroPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ModernAgesHeroPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
