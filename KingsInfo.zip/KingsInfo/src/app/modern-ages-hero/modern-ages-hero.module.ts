import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ModernAgesHeroPageRoutingModule } from './modern-ages-hero-routing.module';

import { ModernAgesHeroPage } from './modern-ages-hero.page';

import { MessagesComponent } from "../messages/messages.component";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ModernAgesHeroPageRoutingModule
  ],
  declarations: [ModernAgesHeroPage,MessagesComponent]
})
export class ModernAgesHeroPageModule {}
