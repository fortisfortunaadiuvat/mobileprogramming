import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'navigation',
    loadChildren: () => import('./navigation/navigation.module').then( m => m.NavigationPageModule)
  },
  {
    path: 'classical-era-hero',
    loadChildren: () => import('./classical-era-hero/classical-era-hero.module').then( m => m.ClassicalEraHeroPageModule)
  },
  {
    path: 'modern-ages-hero',
    loadChildren: () => import('./modern-ages-hero/modern-ages-hero.module').then( m => m.ModernAgesHeroPageModule)
  },
  {
    path: 'early-modern-ages-hero',
    loadChildren: () => import('./early-modern-ages-hero/early-modern-ages-hero.module').then( m => m.EarlyModernAgesHeroPageModule)
  },
  {
    path: 'middle-ages-hero',
    loadChildren: () => import('./middle-ages-hero/middle-ages-hero.module').then( m => m.MiddleAgesHeroPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
