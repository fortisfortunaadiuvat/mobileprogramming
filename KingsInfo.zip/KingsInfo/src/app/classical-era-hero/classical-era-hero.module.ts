import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ClassicalEraHeroPageRoutingModule } from './classical-era-hero-routing.module';

import { ClassicalEraHeroPage } from './classical-era-hero.page';

import { MessagesComponent } from "../messages/messages.component";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ClassicalEraHeroPageRoutingModule,
  ],
  declarations: [ClassicalEraHeroPage,MessagesComponent]
})
export class ClassicalEraHeroPageModule {}
