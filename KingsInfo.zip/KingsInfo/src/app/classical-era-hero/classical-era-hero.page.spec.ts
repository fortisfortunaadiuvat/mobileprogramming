import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ClassicalEraHeroPage } from './classical-era-hero.page';

describe('ClassicalEraHeroPage', () => {
  let component: ClassicalEraHeroPage;
  let fixture: ComponentFixture<ClassicalEraHeroPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClassicalEraHeroPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ClassicalEraHeroPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
